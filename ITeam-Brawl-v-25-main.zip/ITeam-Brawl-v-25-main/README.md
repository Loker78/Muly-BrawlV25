# ITeam-Brawl-v-25
1 server in the world on brawl stars v25 in github


## How to run server?
# PC
- download python 3.7-3.9
- open server files
- install modules - pip install, pip install tinydb
- run main.py file
- server started!

# Mobile
- download termux or pydroid
- open server files
- install modules - pip install, pip install tinydb (on termux install python)
- run main.py file
- server started!

